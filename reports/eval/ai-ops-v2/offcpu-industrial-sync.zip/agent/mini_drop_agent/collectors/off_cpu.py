"""Industrial off-CPU collector based on bpftrace sched_switch tracing."""

from __future__ import annotations

import json
import os
import re
import shutil
import signal
import subprocess
from collections import defaultdict
from typing import Any

from agent.mini_drop_agent.collectors.base import CollectorResult, CollectorTask


class OffCPUCollector:
    """Collect wait stacks with bpftrace instead of disguising perf as off-CPU."""

    OUTPUT_BASE = "/tmp/mini-drop"
    DEFAULT_MIN_WAIT_MS = 1.0
    MAX_THREAD_FILTERS = 256
    STACK_DEPTH = 32

    def collect(self, task: CollectorTask) -> CollectorResult:
        output_dir = os.path.join(self.OUTPUT_BASE, task.id)
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, "off_cpu_wait.json")
        raw_path = os.path.join(output_dir, "bpftrace_offcpu.txt")
        script_path = os.path.join(output_dir, "offcpu.bt")
        evidence_window = _evidence_window(task)

        unavailable = self._preflight(task)
        if unavailable:
            payload = self._empty_payload(
                task,
                evidence_window,
                collector_status="unavailable",
                parser_status=unavailable,
            )
            _write_json(output_path, payload)
            return CollectorResult(
                ok=False,
                reason=f"off-CPU 工业采集器不可用: {unavailable}",
                artifacts=[self._artifact(task, output_path, evidence_window, payload)],
            )

        thread_ids = _thread_ids(task.target_pid)
        if not thread_ids:
            payload = self._empty_payload(
                task,
                evidence_window,
                collector_status="failed",
                parser_status="target_threads_unavailable",
            )
            _write_json(output_path, payload)
            return CollectorResult(
                ok=False,
                reason=f"目标 PID {task.target_pid} 没有可采集线程",
                artifacts=[self._artifact(task, output_path, evidence_window, payload)],
            )

        script = _build_bpftrace_script(thread_ids[: self.MAX_THREAD_FILTERS], task.options)
        with open(script_path, "w", encoding="utf-8") as fh:
            fh.write(script)

        bpftrace_path = shutil.which("bpftrace") or "bpftrace"
        cmd = [bpftrace_path, script_path]
        timeout = task.duration_sec + 20
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                start_new_session=hasattr(os, "setsid"),
            )
            try:
                stdout, stderr = proc.communicate(timeout=task.duration_sec)
            except subprocess.TimeoutExpired:
                _terminate_process_group(proc)
                stdout, stderr = proc.communicate(timeout=5)
        except Exception as exc:
            payload = self._empty_payload(
                task,
                evidence_window,
                collector_status="failed",
                parser_status=f"bpftrace_launch_failed:{exc}",
            )
            _write_json(output_path, payload)
            return CollectorResult(
                ok=False,
                reason=f"bpftrace off-CPU 启动失败: {exc}",
                artifacts=[self._artifact(task, output_path, evidence_window, payload)],
            )

        with open(raw_path, "w", encoding="utf-8") as fh:
            fh.write(stdout or "")
            if stderr:
                fh.write("\n--- STDERR ---\n")
                fh.write(stderr)

        parsed = _parse_bpftrace_output(stdout or "")
        payload = self._payload_from_parsed(
            task,
            evidence_window,
            thread_ids,
            parsed,
            proc.returncode,
            stderr or "",
        )
        _write_json(output_path, payload)

        artifacts = [
            {
                "artifact_type": "raw",
                "filename": "bpftrace_offcpu.txt",
                "local_path": raw_path,
                "content_type": "text/plain",
                "size_bytes": os.path.getsize(raw_path),
                "collector_family": "off_cpu_wait_profile",
                "evidence_window": evidence_window,
                **_cohort_fields(task),
            },
            self._artifact(task, output_path, evidence_window, payload),
        ]
        if payload["summary"]["sample_count"] <= 0:
            return CollectorResult(
                ok=False,
                reason=f"bpftrace off-CPU 未产出等待栈: {payload['parser_status']}",
                artifacts=artifacts,
            )
        return CollectorResult(
            ok=True,
            reason=(
                "bpftrace off-CPU 等待栈采集完成: "
                f"{payload['summary']['sample_count']} 个等待样本, "
                f"Top wait={payload['summary']['top_wait_reason']}"
            ),
            artifacts=artifacts,
        )

    def _preflight(self, task: CollectorTask) -> str:
        if shutil.which("bpftrace") is None:
            return "bpftrace_not_installed"
        if not os.path.isdir(f"/proc/{task.target_pid}"):
            return "target_pid_not_found"
        if os.name != "posix":
            return "linux_required"
        return ""

    def _empty_payload(
        self,
        task: CollectorTask,
        evidence_window: dict[str, Any],
        *,
        collector_status: str,
        parser_status: str,
    ) -> dict[str, Any]:
        return {
            "schema_version": "1.0",
            "task_id": task.id,
            "collector_type": "off_cpu_wait_profile",
            "collector_family": "off_cpu_wait_profile",
            **_cohort_fields(task),
            "collector_invocation": _collector_invocation(task),
            "target_pid": task.target_pid,
            "target_thread_ids": [],
            "evidence_window": evidence_window,
            "collector_status": collector_status,
            "parser_status": parser_status,
            "strategy": {"kind": "bpftrace_sched_switch_offcpu", "fallback_used": False},
            "summary": {
                "sample_count": 0,
                "blocked_thread_count": 0,
                "total_wait_ms": 0.0,
                "top_wait_reason": "",
                "has_wait_reason": False,
            },
            "top_wait_stacks": [],
            "thread_wait_summary": [],
            "syscall_wait_summary": {},
        }

    def _payload_from_parsed(
        self,
        task: CollectorTask,
        evidence_window: dict[str, Any],
        thread_ids: list[int],
        parsed: dict[str, Any],
        returncode: int | None,
        stderr: str,
    ) -> dict[str, Any]:
        top_wait_stacks = parsed["top_wait_stacks"][:10]
        thread_wait_summary = parsed["thread_wait_summary"][:20]
        wait_reason_counts: dict[str, int] = defaultdict(int)
        for item in top_wait_stacks:
            wait_reason_counts[str(item.get("wait_reason") or "unknown")] += int(item.get("samples") or 0)
        top_wait_reason = max(wait_reason_counts.items(), key=lambda item: item[1])[0] if wait_reason_counts else ""
        sample_count = sum(int(item.get("samples") or 0) for item in top_wait_stacks)
        total_wait_ms = round(sum(float(item.get("wait_ms") or 0.0) for item in top_wait_stacks), 2)
        parser_status = parsed["parser_status"]
        if returncode not in (0, -signal.SIGTERM, -signal.SIGINT, None) and not top_wait_stacks:
            parser_status = f"bpftrace_failed:{_compact_error(stderr)}"
        return {
            "schema_version": "1.0",
            "task_id": task.id,
            "collector_type": "off_cpu_wait_profile",
            "collector_family": "off_cpu_wait_profile",
            **_cohort_fields(task),
            "collector_invocation": _collector_invocation(task),
            "target_pid": task.target_pid,
            "target_thread_ids": thread_ids[: self.MAX_THREAD_FILTERS],
            "evidence_window": evidence_window,
            "collector_status": "completed" if sample_count > 0 else "empty",
            "parser_status": parser_status,
            "strategy": {
                "kind": "bpftrace_sched_switch_offcpu",
                "fallback_used": False,
                "stack_depth": self.STACK_DEPTH,
                "min_wait_ms": _safe_float(task.options.get("min_wait_ms"), self.DEFAULT_MIN_WAIT_MS),
            },
            "summary": {
                "sample_count": sample_count,
                "blocked_thread_count": len(thread_wait_summary),
                "total_wait_ms": total_wait_ms,
                "top_wait_reason": top_wait_reason,
                "has_wait_reason": bool(top_wait_reason),
            },
            "top_wait_stacks": top_wait_stacks,
            "thread_wait_summary": thread_wait_summary,
            "syscall_wait_summary": parsed["syscall_wait_summary"],
        }

    @staticmethod
    def _artifact(
        task: CollectorTask,
        output_path: str,
        evidence_window: dict[str, Any],
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        return {
            "artifact_type": "off_cpu_wait_json",
            "filename": "off_cpu_wait.json",
            "local_path": output_path,
            "content_type": "application/json",
            "size_bytes": os.path.getsize(output_path),
            "collector_family": "off_cpu_wait_profile",
            "evidence_window": evidence_window,
            **_cohort_fields(task),
            "metadata": {"data": payload},
        }


def _build_bpftrace_script(thread_ids: list[int], options: dict[str, Any]) -> str:
    predicate = " || ".join(f"args->prev_pid == {tid}" for tid in thread_ids) or "0"
    next_predicate = " || ".join(f"args->next_pid == {tid}" for tid in thread_ids) or "0"
    min_wait_ns = int(_safe_float(options.get("min_wait_ms"), OffCPUCollector.DEFAULT_MIN_WAIT_MS) * 1_000_000)
    depth = int(_safe_float(options.get("stack_depth"), OffCPUCollector.STACK_DEPTH))
    depth = max(1, min(depth, 127))
    return f"""
BEGIN
{{
  printf("mini-drop offcpu bpftrace start\\n");
}}

tracepoint:sched:sched_switch /{predicate}/
{{
  @start[args->prev_pid] = nsecs;
  @state[args->prev_pid] = args->prev_state;
  @ustack[args->prev_pid] = ustack({depth});
}}

tracepoint:sched:sched_switch /({next_predicate}) && @start[args->next_pid]/
{{
  $delta = nsecs - @start[args->next_pid];
  if ($delta >= {min_wait_ns}) {{
    @wait_ns[@ustack[args->next_pid], @state[args->next_pid]] = sum($delta);
    @wait_count[@ustack[args->next_pid], @state[args->next_pid]] = count();
    @thread_wait_ns[args->next_pid] = sum($delta);
  }}
  delete(@start[args->next_pid]);
  delete(@state[args->next_pid]);
  delete(@ustack[args->next_pid]);
}}

END
{{
  print(@wait_ns);
  print(@wait_count);
  print(@thread_wait_ns);
}}
""".strip()


def _parse_bpftrace_output(text: str) -> dict[str, Any]:
    stack_wait_ns: dict[tuple[tuple[str, ...], str], float] = defaultdict(float)
    stack_counts: dict[tuple[tuple[str, ...], str], int] = defaultdict(int)
    thread_wait_ns: dict[int, float] = defaultdict(float)
    for event in _parse_json_events(text):
        stack = tuple(event["stack"])
        reason = _wait_reason(event.get("state"))
        key = (stack, reason)
        stack_wait_ns[key] += float(event.get("wait_ns") or 0.0)
        stack_counts[key] += 1
        if event.get("tid"):
            thread_wait_ns[int(event["tid"])] += float(event.get("wait_ns") or 0.0)
    if not stack_wait_ns:
        maps = _parse_printed_maps(text)
        stack_wait_ns.update(maps["stack_wait_ns"])
        stack_counts.update(maps["stack_counts"])
        thread_wait_ns.update(maps["thread_wait_ns"])

    total_wait_ns = sum(stack_wait_ns.values())
    top_wait_stacks = []
    for index, ((stack, reason), wait_ns) in enumerate(
        sorted(stack_wait_ns.items(), key=lambda item: (-item[1], item[0][1], item[0][0]))[:10]
    ):
        samples = stack_counts.get((stack, reason), 0)
        wait_ms = wait_ns / 1_000_000.0
        top_wait_stacks.append({
            "wait_reason": reason,
            "stack": list(stack),
            "top_frame": stack[0] if stack else "",
            "samples": samples,
            "wait_ms": round(wait_ms, 2),
            "percent": round((wait_ns / total_wait_ns * 100.0), 2) if total_wait_ns else 0.0,
            "evidence_ref": f"off_cpu_wait.top_wait_stacks[{index}]",
        })
    thread_wait_summary = [
        {
            "tid": tid,
            "wait_ms": round(wait_ns / 1_000_000.0, 2),
            "evidence_ref": f"off_cpu_wait.thread_wait_summary[{index}]",
        }
        for index, (tid, wait_ns) in enumerate(sorted(thread_wait_ns.items(), key=lambda item: -item[1])[:20])
    ]
    syscall_wait_summary: dict[str, int] = defaultdict(int)
    for item in top_wait_stacks:
        family = _syscall_family(item["stack"])
        if family:
            syscall_wait_summary[family] += int(item["samples"] or 0)
    return {
        "top_wait_stacks": top_wait_stacks,
        "thread_wait_summary": thread_wait_summary,
        "syscall_wait_summary": dict(syscall_wait_summary),
        "parser_status": "ok" if top_wait_stacks else "empty_bpftrace_output",
    }


def _parse_json_events(text: str) -> list[dict[str, Any]]:
    events = []
    for line in text.splitlines():
        raw = line.strip()
        if not raw.startswith("{"):
            continue
        try:
            item = json.loads(raw)
        except json.JSONDecodeError:
            continue
        stack = item.get("stack")
        if isinstance(stack, str):
            stack = [part for part in stack.split(";") if part]
        if not isinstance(stack, list):
            continue
        events.append({
            "tid": _safe_int(item.get("tid"), 0),
            "wait_ns": _safe_float(item.get("wait_ns"), 0.0),
            "state": item.get("state"),
            "stack": [str(frame).strip() for frame in stack if str(frame).strip()],
        })
    return events


def _parse_printed_maps(text: str) -> dict[str, Any]:
    stack_wait_ns: dict[tuple[tuple[str, ...], str], float] = defaultdict(float)
    stack_counts: dict[tuple[tuple[str, ...], str], int] = defaultdict(int)
    thread_wait_ns: dict[int, float] = defaultdict(float)
    for line in text.splitlines():
        match = re.match(r"@thread_wait_ns\[(\d+)\]:\s*(\d+(?:\.\d+)?)", line.strip())
        if match:
            thread_wait_ns[int(match.group(1))] += float(match.group(2))
    for map_name in ("wait_ns", "wait_count"):
        for stack, state, value in _iter_stack_map_entries(text, map_name):
            key = (tuple(stack), _wait_reason(state))
            if map_name == "wait_ns":
                stack_wait_ns[key] += value
            else:
                stack_counts[key] += int(value)
    return {
        "stack_wait_ns": stack_wait_ns,
        "stack_counts": stack_counts,
        "thread_wait_ns": thread_wait_ns,
    }


def _iter_stack_map_entries(text: str, map_name: str):
    pattern = re.compile(rf"@{map_name}\[(.*?)\]:\s*(\d+(?:\.\d+)?)", re.DOTALL)
    for match in pattern.finditer(text):
        raw_key = match.group(1)
        stack, state = _split_stack_key(raw_key)
        if stack:
            yield stack, state, float(match.group(2))


def _split_stack_key(raw_key: str) -> tuple[list[str], int | str]:
    state: int | str = ""
    key = raw_key.strip()
    state_match = re.search(r",\s*(-?\d+)\s*$", key)
    if state_match:
        state = int(state_match.group(1))
        key = key[: state_match.start()]
    stack = []
    for raw_line in key.splitlines():
        frame = raw_line.strip()
        if not frame or frame in {"user stack", "kernel stack", "ustack"}:
            continue
        if frame.startswith("@") or frame.endswith("["):
            continue
        stack.append(frame[:256])
    return stack, state


def _wait_reason(state: Any) -> str:
    value = _safe_int(state, 0)
    if value == 0:
        return "runnable_preempted"
    if value & 2:
        return "uninterruptible_io_or_kernel_wait"
    if value & 1:
        return "interruptible_sleep_or_lock_wait"
    if value & 4:
        return "stopped"
    if value & 8:
        return "traced"
    if value & 16:
        return "dead"
    return f"sched_state_{value}"


def _syscall_family(stack: list[str]) -> str:
    text = " ".join(stack).lower()
    if "futex" in text or "pthread_mutex" in text or "lock" in text:
        return "futex_or_lock"
    if "epoll" in text or "poll" in text or "select" in text:
        return "poll_wait"
    if "nanosleep" in text or "sleep" in text:
        return "sleep"
    if "read" in text or "write" in text or "recv" in text or "send" in text:
        return "io_or_socket"
    return ""


def _thread_ids(pid: int) -> list[int]:
    task_dir = f"/proc/{pid}/task"
    try:
        return sorted(int(item) for item in os.listdir(task_dir) if item.isdigit())
    except (FileNotFoundError, PermissionError, ValueError):
        return []


def _terminate_process_group(proc: subprocess.Popen) -> None:
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    except Exception:
        try:
            proc.terminate()
        except Exception:
            pass


def _write_json(path: str, payload: dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)


def _collector_invocation(task: CollectorTask) -> dict[str, Any]:
    invocation = task.options.get("collector_invocation")
    if isinstance(invocation, dict):
        return invocation
    return {
        "schema_version": "1.0",
        "scope_source": "task_options",
        "collector_family": "off_cpu_wait_profile",
        "target_config": {"pid": task.target_pid},
    }


def _cohort_fields(task: CollectorTask) -> dict[str, Any]:
    return {
        "trigger_event_id": task.options.get("trigger_event_id"),
        "evidence_cohort_id": task.options.get("evidence_cohort_id"),
        "collection_mode": task.options.get("collection_mode") or "manual_single",
        "timing_relation": task.options.get("timing_relation") or "unknown",
    }


def _evidence_window(task: CollectorTask) -> dict[str, Any]:
    return {
        "window_start": task.options.get("window_start"),
        "window_end": task.options.get("window_end"),
        "duration_sec": task.duration_sec,
        **_cohort_fields(task),
    }


def _compact_error(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()[:200]


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default
